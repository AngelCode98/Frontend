class Usuario {
    constructor(identificacion, usuario, correo, contraseña) {
        this.identificacion = identificacion;
        this.usuario = usuario;
        this.correo = correo;
        this.contraseña = contraseña;
        this.saldo = 0;
        this.transacciones = [];
    }

    depositar(monto) {
        if (monto > 0) {
            this.saldo += monto;
            this.transacciones.push({ tipo: 'Depósito', monto, saldo: this.saldo, fecha: new Date() });
            console.log(`¡Depósito exitoso! Nuevo saldo: $${this.saldo}`);
        } else {
            console.log("El monto debe ser positivo.");
        }
    }

    retirar(monto) {
        if (monto > 0 && monto <= this.saldo) {
            this.saldo -= monto;
            this.transacciones.push({ tipo: 'Retiro', monto, saldo: this.saldo, fecha: new Date() });
            console.log(`¡Retiro exitoso! Nuevo saldo: $${this.saldo}`);
        } else {
            console.log("Monto de retiro inválido.");
        }
    }

    consultarSaldo() {
        console.log(`Saldo actual: $${this.saldo}`);
    }

    verTransacciones() {
        console.log("Historial de Transacciones:");
        this.transacciones.forEach(transaccion => {
            console.log(`${transaccion.fecha.toLocaleString()}\t ${transaccion.tipo} \t$${transaccion.monto}\t $${transaccion.saldo}`);
        });
    }

    cambiarContraseña(nuevaContraseña) {
        this.contraseña = nuevaContraseña;
        console.log("Contraseña cambiada exitosamente.");
    }
}


class SistemaBancario {
    constructor() {
        this.usuarios = [];
    }

    registrar(identificacion, usuario, correo, contraseña, confirmarContraseña) {
        if (contraseña !== confirmarContraseña) {
            console.log("Las contraseñas no coinciden.");
            return;
        }
        const nuevoUsuario = new Usuario(identificacion, usuario, correo, contraseña);
        this.usuarios.push(nuevoUsuario);
        console.log("¡Registro exitoso!");
    }

    iniciarSesion(usuario, contraseña) {
        const usuarioEncontrado = this.usuarios.find(u => u.usuario === usuario && u.contraseña === contraseña);
        if (usuarioEncontrado) {
            console.log("¡Inicio de sesión exitoso!");
            return usuarioEncontrado;
        } else {
            console.log("Credenciales inválidas.");
            return null;
        }
    }
}

const banco = new SistemaBancario();

function registrarUsuario() {
    const identificacion = prompt("Ingrese su identificación:");
    const usuario = prompt("Ingrese su nombre de usuario:");
    const correo = prompt("Ingrese su correo:");
    const contraseña = prompt("Ingrese su contraseña:");
    const confirmarContraseña = prompt("Confirme su contraseña:");
    banco.registrar(identificacion, usuario, correo, contraseña, confirmarContraseña);
}

function iniciarSesionUsuario() {
    const usuario = prompt("Ingrese su nombre de usuario:");
    const contraseña = prompt("Ingrese su contraseña:");
    let usuarioEncontrado = null;
    let intentos = 0;

    while (intentos < 3) {
        usuarioEncontrado = banco.iniciarSesion(usuario, contraseña);
        if (usuarioEncontrado) {
            break;
        }
        intentos++;
        console.log(`Intento ${intentos} de 3`);
        if (intentos === 3) {
            console.log("Cuenta bloqueada por 24 horas. Comuníquese con su banco.");
            return;
        }
        contraseña = prompt("Intente de nuevo. Ingrese su contraseña:");
    }

    mostrarMenuUsuario(usuarioEncontrado);
}

function mostrarMenuUsuario(usuario) {
    let opcion;
    do {
        opcion = prompt("Elija una opción:\n1. Depositar\n2. Retirar\n3. Consultar Saldo\n4. Ver Transacciones\n5. Cambiar Contraseña\n6. Cerrar Sesión");
        switch (opcion) {
            case '1':
                const montoDeposito = parseFloat(prompt("Ingrese el monto a depositar:"));
                usuario.depositar(montoDeposito);
                break;
            case '2':
                const montoRetiro = parseFloat(prompt("Ingrese el monto a retirar:"));
                usuario.retirar(montoRetiro);
                break;
            case '3':
                usuario.consultarSaldo();
                break;
            case '4':
                usuario.verTransacciones();
                break;
            case '5':
                const nuevaContraseña = prompt("Ingrese la nueva contraseña:");
                usuario.cambiarContraseña(nuevaContraseña);
                break;
            case '6':
                console.log("Cerrando sesión...");
                break;
            default:
                console.log("Opción inválida. Por favor, intente de nuevo.");
        }
    } while (opcion !== '6');
}

function menuPrincipal() {
    let opcion;
    do {
        opcion = prompt("¡Bienvenido al Sistema Bancario CESDE!\n1. Registrar\n2. Iniciar Sesión\n3. Salir");
        switch (opcion) {
            case '1':
                registrarUsuario();
                break;
            case '2':
                iniciarSesionUsuario();
                break;
            case '3':
                console.log("Saliendo del sistema. ¡Hasta luego!");
                break;
            default:
                console.log("Opción inválida. Por favor, intente de nuevo.");
        }
    } while (opcion !== '3');
}

// y vueeeeeeelve 😎
menuPrincipal();